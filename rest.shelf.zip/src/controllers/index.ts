import ShelfController from "./shelf.controller";
import BookController from "./book.controller";
import LibraryController from "./library.controller";

export { BookController, ShelfController, LibraryController }
